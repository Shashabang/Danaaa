package com.android.foodorderapp;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class HistoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        // First Order
        TextView orderDateTime1 = findViewById(R.id.orderDateTime1);
        final TextView itemsOrdered1 = findViewById(R.id.itemsOrdered1);
        final TextView itemPrice1 = findViewById(R.id.itemPrice1);
        final TextView totalAmount1 = findViewById(R.id.totalAmount1);
        final TextView orderStatus1 = findViewById(R.id.orderStatus1);
        final TextView paymentMethod1 = findViewById(R.id.paymentMethod1);
        final TextView restaurantName1 = findViewById(R.id.restaurantName1);
        final TextView deliveryRider1 = findViewById(R.id.deliveryRider1);

        orderDateTime1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Toggle visibility of order details for first order
                toggleVisibility(itemsOrdered1, itemPrice1, totalAmount1, orderStatus1, paymentMethod1, restaurantName1, deliveryRider1);
            }
        });

        // Second Order
        TextView orderDateTime2 = findViewById(R.id.orderDateTime2);
        final TextView itemsOrdered2 = findViewById(R.id.itemsOrdered2);
        final TextView itemPrice2 = findViewById(R.id.itemPrice2);
        final TextView totalAmount2 = findViewById(R.id.totalAmount2);
        final TextView orderStatus2 = findViewById(R.id.orderStatus2);
        final TextView paymentMethod2 = findViewById(R.id.paymentMethod2);
        final TextView restaurantName2 = findViewById(R.id.restaurantName2);
        final TextView deliveryRider2 = findViewById(R.id.deliveryRider2);

        orderDateTime2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Toggle visibility of order details for second order
                toggleVisibility(itemsOrdered2, itemPrice2, totalAmount2, orderStatus2, paymentMethod2, restaurantName2, deliveryRider2);
            }
        });
    }

    // Method to toggle visibility of order details (items, price, total, status, payment method, restaurant name, delivery rider)
    private void toggleVisibility(TextView items, TextView price, TextView total, TextView status, TextView paymentMethod, TextView restaurantName, TextView deliveryRider) {
        int visibility = items.getVisibility() == View.GONE ? View.VISIBLE : View.GONE;

        items.setVisibility(visibility);
        price.setVisibility(visibility);
        total.setVisibility(visibility);
        status.setVisibility(visibility);
        paymentMethod.setVisibility(visibility);
        restaurantName.setVisibility(visibility);
        deliveryRider.setVisibility(visibility);
    }
}

