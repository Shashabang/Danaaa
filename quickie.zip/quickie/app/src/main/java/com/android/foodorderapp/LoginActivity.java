package com.android.foodorderapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private Button loginButton;
    private TextView signUpText;
    private EditText passwordEditText;
    private ImageView eyeIcon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login); // Use your correct layout XML

        loginButton = findViewById(R.id.login);
        signUpText = findViewById(R.id.tvDontHaveAccount);
        passwordEditText = findViewById(R.id.editTextTextPassword); // Correct ID for password EditText
        eyeIcon = findViewById(R.id.eye_icon); // Correct ID for eye icon

        // Apply underline to the "Don't have an account? Sign up" text
        SpannableString content = new SpannableString(getString(R.string.underlined_text));
        content.setSpan(new UnderlineSpan(), 0, content.length(), 0);
        signUpText.setText(content);

        // Set OnClickListener for Log In button
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to MainActivity
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        // Set OnClickListener for Sign Up text view
        signUpText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to Sign Up activity
                Intent intent = new Intent(LoginActivity.this, SignUpActivity.class);
                startActivity(intent);
            }
        });

        eyeIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the current input type of the password field
                int currentInputType = passwordEditText.getInputType();

                // Store the original input type, so it doesn't change on toggle
                int originalInputType = passwordEditText.getInputType();

                // Check if the password is hidden (password type input)
                if ((currentInputType & android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD) != 0) {
                    // Change to show password by removing the password input type flag
                    passwordEditText.setInputType(originalInputType & ~android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    eyeIcon.setImageResource(R.drawable.ic_eye_open); // Set open eye icon
                } else {
                    // Change to hide password by adding the password input type flag
                    passwordEditText.setInputType(originalInputType | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    eyeIcon.setImageResource(R.drawable.ic_eye); // Set closed eye icon
                }

                // Ensure that the focus remains in the correct place after the input type change
                passwordEditText.setSelection(passwordEditText.getText().length());
            }
        });
    }
}

