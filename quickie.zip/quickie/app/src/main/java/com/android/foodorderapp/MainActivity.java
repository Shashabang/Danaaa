package com.android.foodorderapp;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;

import com.android.foodorderapp.adapters.RestaurantListAdapter;
import com.android.foodorderapp.model.RestaurantModel;
import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity implements RestaurantListAdapter.RestaurantListClickListener {

    private RecyclerView recyclerView;
    private RestaurantListAdapter adapter;
    private List<RestaurantModel> restaurantModelList;
    private List<RestaurantModel> filteredList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Setup ActionBar with a custom view
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayShowCustomEnabled(true);
            actionBar.setDisplayShowTitleEnabled(false);

            // Create a custom layout for the ActionBar
            androidx.appcompat.widget.Toolbar customToolbar = new androidx.appcompat.widget.Toolbar(this);
            customToolbar.setPadding(10, 0, 10, 0);

            // Add Title
            TextView titleTextView = new TextView(this);
            titleTextView.setText("Fastfood Restaurants");
            titleTextView.setTextSize(20);
            titleTextView.setTextColor(getResources().getColor(android.R.color.white));
            titleTextView.setLayoutParams(new androidx.appcompat.widget.Toolbar.LayoutParams(
                    androidx.appcompat.widget.Toolbar.LayoutParams.WRAP_CONTENT,
                    androidx.appcompat.widget.Toolbar.LayoutParams.WRAP_CONTENT,
                    Gravity.START
            ));

            // Add OrderHistory Button
            TextView orderHistoryTextView = new TextView(this);
            orderHistoryTextView.setText("OrderHistory");
            orderHistoryTextView.setTextSize(18);
            orderHistoryTextView.setTextColor(getResources().getColor(android.R.color.white));
            orderHistoryTextView.setTypeface(null, android.graphics.Typeface.ITALIC);
            orderHistoryTextView.setPaintFlags(orderHistoryTextView.getPaintFlags() | android.graphics.Paint.UNDERLINE_TEXT_FLAG);
            orderHistoryTextView.setLayoutParams(new androidx.appcompat.widget.Toolbar.LayoutParams(
                    androidx.appcompat.widget.Toolbar.LayoutParams.WRAP_CONTENT,
                    androidx.appcompat.widget.Toolbar.LayoutParams.WRAP_CONTENT,
                    Gravity.END
            ));

            androidx.appcompat.widget.Toolbar.LayoutParams params = new androidx.appcompat.widget.Toolbar.LayoutParams(
                    androidx.appcompat.widget.Toolbar.LayoutParams.WRAP_CONTENT,
                    androidx.appcompat.widget.Toolbar.LayoutParams.WRAP_CONTENT,
                    Gravity.END
            );
            params.setMargins(170, 0, 0, 0); // Left, Top, Right, Bottom margins
            orderHistoryTextView.setLayoutParams(params);

            // Set OnClickListener to navigate to HistoryActivity
            orderHistoryTextView.setOnClickListener(v -> {
                Intent intent = new Intent(MainActivity.this, HistoryActivity.class);
                startActivity(intent);
            });

            // Add views to the Toolbar
            customToolbar.addView(titleTextView);
            customToolbar.addView(orderHistoryTextView);

            // Add the custom Toolbar to the ActionBar
            actionBar.setCustomView(customToolbar);
        }

        // Get Restaurant data
        restaurantModelList = getRestaurantData();
        filteredList = new ArrayList<>(restaurantModelList); // Clone the list for filtering

        // Initialize RecyclerView and SearchView
        initRecyclerView(filteredList);
        initSearchView();
    }

    private void initRecyclerView(List<RestaurantModel> list) {
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new RestaurantListAdapter(list, this);
        recyclerView.setAdapter(adapter);
    }

    private void initSearchView() {
        SearchView searchView = findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false; // No action needed on submit
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterList(newText);
                return true;
            }
        });
    }

    private List<RestaurantModel> getRestaurantData() {
        InputStream is = getResources().openRawResource(R.raw.restaurent);
        Writer writer = new StringWriter();
        char[] buffer = new char[1024];
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            int n;
            while ((n = reader.read(buffer)) != -1) {
                writer.write(buffer, 0, n);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        String jsonStr = writer.toString();
        Gson gson = new Gson();
        RestaurantModel[] restaurantModels = gson.fromJson(jsonStr, RestaurantModel[].class);
        return Arrays.asList(restaurantModels);
    }

    private void filterList(String query) {
        filteredList.clear();
        if (query.isEmpty()) {
            filteredList.addAll(restaurantModelList);
        } else {
            for (RestaurantModel model : restaurantModelList) {
                if (model.getName().toLowerCase().contains(query.toLowerCase())) {
                    filteredList.add(model);
                }
            }
        }
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onItemClick(RestaurantModel restaurantModel) {
        Intent intent = new Intent(MainActivity.this, RestaurantMenuActivity.class);
        intent.putExtra("RestaurantModel", restaurantModel);
        startActivity(intent);
    }
}


