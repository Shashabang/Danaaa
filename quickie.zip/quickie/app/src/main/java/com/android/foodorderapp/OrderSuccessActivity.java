package com.android.foodorderapp;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.foodorderapp.model.RestaurantModel;
import com.bumptech.glide.Glide;

public class OrderSuccessActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_succeess);

        // Get restaurant and payment method data
        RestaurantModel restaurantModel = getIntent().getParcelableExtra("RestaurantModel");
        boolean isPayByCard = getIntent().getBooleanExtra("isPayByCard", false);

        // Set up action bar
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setTitle(restaurantModel.getName());
            actionBar.setSubtitle(restaurantModel.getAddress());
            actionBar.setDisplayHomeAsUpEnabled(false);
        }

        // Set success message based on payment method
        TextView successMessage = findViewById(R.id.successMessage);
        if (isPayByCard) {
            successMessage.setText("Your order has been successfully placed, and your payment has been processed. Expect your delivery soon.");
        } else {
            successMessage.setText("Your order has been successfully placed. Please ensure cash is ready for payment at the time of delivery.");
        }

        // Handle the Done button
        TextView buttonDone = findViewById(R.id.buttonDone);
        buttonDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redirect to MainActivity
                Intent intent = new Intent(OrderSuccessActivity.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK); // Clear stack
                startActivity(intent);
                finish();
            }
        });

        // Load the motor image using Glide
        ImageView imageViewMotor = findViewById(R.id.imageViewMotor);
        Glide.with(this)
                .load(R.drawable.motor) // Your motor.png image
                .into(imageViewMotor);

        // Set the Delivery Rider Details text with underline
        TextView deliveryRiderDetails = findViewById(R.id.deliveryRiderDetails);
        String text = "Delivery Rider Details";
        SpannableString spannableString = new SpannableString(text);
        spannableString.setSpan(new UnderlineSpan(), 0, text.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        deliveryRiderDetails.setText(spannableString);

        // Optional: Handle the click event for the Delivery Rider Details text
        deliveryRiderDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Perform action when the text is clicked, e.g., open a new activity
                Intent intent = new Intent(OrderSuccessActivity.this, DeliveryRiderActivity.class);
                startActivity(intent);
            }
        });
    }
}

