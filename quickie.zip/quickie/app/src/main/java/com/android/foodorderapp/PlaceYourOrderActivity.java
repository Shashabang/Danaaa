package com.android.foodorderapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.android.foodorderapp.adapters.PlaceYourOrderAdapter;
import com.android.foodorderapp.model.Menu;
import com.android.foodorderapp.model.RestaurantModel;

public class PlaceYourOrderActivity extends AppCompatActivity {

    private EditText inputName, inputAddress, inputCity, inputState, inputZip, inputCardNumber, inputCardExpiry, inputCardPin;
    private TextView tvCardDetails, tvSubtotalAmount, tvDeliveryChargeAmount, tvDeliveryCharge, tvTotalAmount, buttonPlaceYourOrder;
    private SwitchCompat switchDelivery;
    private RecyclerView cartItemsRecyclerView;
    private boolean isPayByCard = false; // Default to Cash on Delivery
    private PlaceYourOrderAdapter placeYourOrderAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_your_order);

        // Retrieve restaurant details from intent
        RestaurantModel restaurantModel = getIntent().getParcelableExtra("RestaurantModel");

        // Setup action bar
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setTitle(restaurantModel.getName());
            actionBar.setSubtitle(restaurantModel.getAddress());
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        // Initialize views
        initializeViews();

        // Set default visibility for payment method views
        switchDelivery.setChecked(false);
        setViewVisibilityForPaymentMethod(false);

        // Set up switch for payment method
        switchDelivery.setOnCheckedChangeListener((buttonView, isChecked) -> {
            isPayByCard = isChecked;
            setViewVisibilityForPaymentMethod(isChecked);
            calculateTotalAmount(restaurantModel);
        });

        // Handle order button click
        buttonPlaceYourOrder.setOnClickListener(v -> onPlaceOrderButtonClick(restaurantModel));

        // Initialize RecyclerView
        initRecyclerView(restaurantModel);

        // Calculate the initial total amount
        calculateTotalAmount(restaurantModel);
    }

    private void initializeViews() {
        inputName = findViewById(R.id.inputName);
        inputAddress = findViewById(R.id.inputAddress);
        inputCity = findViewById(R.id.inputCity);
        inputState = findViewById(R.id.inputState);
        inputZip = findViewById(R.id.inputZip);
        tvCardDetails = findViewById(R.id.tvCardDetails);
        inputCardNumber = findViewById(R.id.inputCardNumber);
        inputCardExpiry = findViewById(R.id.inputCardName);
        inputCardPin = findViewById(R.id.inputCardPin);
        tvSubtotalAmount = findViewById(R.id.tvSubtotalAmount);
        tvDeliveryChargeAmount = findViewById(R.id.tvDeliveryChargeAmount);
        tvDeliveryCharge = findViewById(R.id.tvDeliveryCharge);
        tvTotalAmount = findViewById(R.id.tvTotalAmount);
        buttonPlaceYourOrder = findViewById(R.id.buttonPlaceYourOrder);
        switchDelivery = findViewById(R.id.switchDelivery);
        cartItemsRecyclerView = findViewById(R.id.cartItemsRecyclerView);
    }

    private void setViewVisibilityForPaymentMethod(boolean isPayByCard) {
        if (isPayByCard) {
            // Show card details for Pay by Card
            inputName.setVisibility(View.VISIBLE); // Show cardholder name
            tvCardDetails.setVisibility(View.VISIBLE);
            inputCardNumber.setVisibility(View.VISIBLE);
            inputCardExpiry.setVisibility(View.VISIBLE);
            inputCardPin.setVisibility(View.VISIBLE);
        } else {
            // Hide card details for Cash on Delivery
            inputName.setVisibility(View.GONE); // Hide cardholder name
            tvCardDetails.setVisibility(View.GONE);
            inputCardNumber.setVisibility(View.GONE);
            inputCardExpiry.setVisibility(View.GONE);
            inputCardPin.setVisibility(View.GONE);
        }

        // Delivery charge should always be visible
        tvDeliveryCharge.setVisibility(View.VISIBLE);
        tvDeliveryChargeAmount.setVisibility(View.VISIBLE);
    }

    private void calculateTotalAmount(RestaurantModel restaurantModel) {
        float subTotal = 0f;

        // Calculate the subtotal
        for (Menu menu : restaurantModel.getMenus()) {
            subTotal += menu.getPrice() * menu.getTotalInCart();
        }

        // Display the subtotal
        tvSubtotalAmount.setText("₱" + String.format("%.2f", subTotal));

        // Delivery charge applies regardless of payment method
        float deliveryCharge = restaurantModel.getDelivery_charge();

        // Display delivery charge
        tvDeliveryChargeAmount.setText("₱" + String.format("%.2f", deliveryCharge));

        // Calculate total amount
        float total = subTotal + deliveryCharge;

        // Display the total amount
        tvTotalAmount.setText("₱" + String.format("%.2f", total));
    }

    private void onPlaceOrderButtonClick(RestaurantModel restaurantModel) {
        Intent intent = new Intent(PlaceYourOrderActivity.this, OrderSuccessActivity.class);
        intent.putExtra("RestaurantModel", restaurantModel);
        intent.putExtra("isPayByCard", isPayByCard); // Pass payment method
        startActivity(intent);
    }


    private void initRecyclerView(RestaurantModel restaurantModel) {
        cartItemsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        placeYourOrderAdapter = new PlaceYourOrderAdapter(restaurantModel.getMenus());
        cartItemsRecyclerView.setAdapter(placeYourOrderAdapter);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == 1000) {
            if (resultCode == Activity.RESULT_OK) {
                setResult(Activity.RESULT_OK);
                finish();
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        setResult(Activity.RESULT_CANCELED);
        super.onBackPressed();
    }

}
